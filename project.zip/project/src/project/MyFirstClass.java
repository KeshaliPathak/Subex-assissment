package project;

public class MyFirstClass {

	public static void main(String[] args) {
		System.out.println("args length" + args.length);
		int num = Integer.parseInt(args[0]);
		int reducer = num;
		int temp = num;
		int result = 0;
		while (reducer > 0) {
			temp = reducer % 10;
			System.out.println("temp" + temp);
			reducer = reducer / 10;
			System.out.println("reducer" + reducer);
			result = result + (temp * temp * temp);
			System.out.println("result" + result);
		}
		if (num == result) {
			System.out.println("the num is armsrong");
		} else {
			System.out.println("the num is not armstrong");
		}
	}
}